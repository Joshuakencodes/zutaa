import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

interface LoginSignupPopupProps {
  onClose: () => void
}

export function LoginSignupPopup({ onClose }: LoginSignupPopupProps) {
  const [isLogin, setIsLogin] = useState(true)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle login/signup logic here
    console.log('Form submitted')
    onClose()
  }

  return (
    <Card className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <CardContent className="bg-white p-6 rounded-lg max-w-md w-full">
        <CardHeader>
          <CardTitle className="text-2xl font-bold mb-2">{isLogin ? 'Log In' : 'Sign Up'}</CardTitle>
        </CardHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input type="email" placeholder="Email" required />
          <Input type="password" placeholder="Password" required />
          {!isLogin && <Input type="password" placeholder="Confirm Password" required />}
          <Button type="submit" className="w-full">{isLogin ? 'Log In' : 'Sign Up'}</Button>
        </form>
        <p className="mt-4 text-center">
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <Button variant="link" onClick={() => setIsLogin(!isLogin)}>
            {isLogin ? 'Sign Up' : 'Log In'}
          </Button>
        </p>
        <Button variant="outline" onClick={onClose} className="mt-4 w-full">
          Close
        </Button>
      </CardContent>
    </Card>
  )
}

